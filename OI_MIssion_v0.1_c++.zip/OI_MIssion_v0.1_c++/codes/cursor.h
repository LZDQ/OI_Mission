#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000) ? 1:0)
int lastmv;
bool kb_down[300];
int rowsiz=16,colsiz=8;
inline bool KB_DOWN(int ch){
	return KEY_DOWN(ch);
} 
inline void RenewKeyboard(){
}
inline void gotoxy(int x, int y) {
	x--,y--;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), (COORD){y,x});
	//printf("\033[%d;%dH",x,y);
}
inline void HideCur() {
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &CursorInfo);
	CursorInfo.bVisible = 0;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &CursorInfo);
}
inline void ShowCur() {
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &CursorInfo);
	CursorInfo.bVisible = 1;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &CursorInfo);
}
double MouseX,MouseY;
inline bool ChkLD(){
	return KB_DOWN(MOUSE_MOVED);
}
inline void InitCursor(){	//return ;
	ShowCur();
	SetColor(Normal,BGnormal);
	system("@echo off");
	system("mode con cols=135 lines=40");
	system("chcp 936");
	memset(kb_down,0,sizeof(kb_down));
	ifstream fin("../cursor.txt");
	fin>>colsiz>>rowsiz;
	fin.close();
	return ;
} 
inline void RenewMouse(bool force=0){
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient(GetForegroundWindow(),&pt);
	swap(pt.x,pt.y);
	MouseX=(double)(pt.x)/rowsiz+0.5;
	MouseY=(double)(pt.y)/colsiz+0.5;
}
