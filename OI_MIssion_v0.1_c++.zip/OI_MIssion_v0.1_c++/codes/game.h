namespace Direct{
	const int DIRE[2][4]={
		{-1,0,1,0},
		{0,-1,0,1}
		// 0 1 2 3
		// W A S D
		// ^1
	};
	const char DIRE_CH[5]="^<v>";
	int getDir(int dx,int dy){
		for(int i=0; i<4; i++)
			if(dx==DIRE[0][i]&&dy==DIRE[1][i]) return i;
		fout<<"getDir failed"<<endl;
		return -1;
	}
}
using namespace Direct;

#define _cls() cls(),EmptyShow()
namespace Game{
	const int N=100,M=100;
	void SaveGame();
	void LockView();
	void StartCustomize();
	void Move(int,int,int);
	void ShowStory(string);
	string GetRandName();
	void Beginner();
	void EncryptAll();
	struct data_t{
		char name[50];
		int plot,hadwp,hadab,rp,rating;
		int w1,w2,abiQ,abiE;
		inline void Save(){
			ofstream fout("store",ios::out|ios::binary);
			fout.write((char*)this,sizeof(data_t));
			fout.close();
			EncryptF("./store");
		}
		inline void Init(){
			cls();
			ifstream fin("store",ios::binary);
			if(fin.is_open()){
				fin.read(tmps,sizeof(data_t));
				fin.close();
				Encrypt(tmps,sizeof(data_t));
				memcpy(this,tmps,sizeof(data_t));
			}else{
				puts("����������֣�");
				cin.getline(name,sizeof(name));
				plot=-1;
				hadwp=hadab=rp=rating=w1=w2=abiQ=abiE=0;
				Save();
			}
			return ;
		}
	}dat;
	struct charNode{
		char ch;
		int fg,bg;
		inline void setFG(int x){ fg=x; }
		inline void setBG(int x){ bg=x; }
		charNode(char a=' ',int b=Normal,int c=BGnormal){
			ch=a,fg=b,bg=c;
		}
		void Init(char c1,char c2,char c3){
			ch=c1;
			fg=getFG(c2);
			bg=getBG(c3);
		}
	}mp[N][M*2],show[45][140];
	typedef charNode cN;
	bool operator ==(cN a,cN b){
		return a.ch == b.ch && a.fg == b.fg && a.bg == b.bg;
	}
	cN operator +(cN a,cN b){
		if(~b.ch) a.ch=b.ch;
		if(~b.fg) a.fg=b.fg;
		if(~b.bg) a.bg=b.bg;
		return a;
	}
	cN operator +=(cN &a,cN b){
		if(~b.ch) a.ch=b.ch;
		if(~b.fg) a.fg=b.fg;
		if(~b.bg) a.bg=b.bg;
		return a;
	}
	namespace Output{
		long clrtm,gototm,puttm;
		bool upd[45][140];
		cN lastshow[45][140];
		//int lx=-1,ly=-1,lstfg=Normal,lstbg=BGnormal;
		inline void OutputMap(){	//�����ͼ�ǳ�������֪��Ϊɶ
			clrtm=gototm=puttm=0;
			gt(tm);
			for(int i=1; i<40; i++)
				for(int j=1; j<=132; j++)
					upd[i][j]=!(lastshow[i][j]==show[i][j]);
			for(int i=1; i<40; i++){
				for(int x=1,y; x<=132; x=y){
					if(!upd[i][x]){
						y=x+1;
						continue;
					}
					y=x;
					while(y<=132 && upd[i][y] && show[i][x].fg==show[i][y].fg && show[i][x].bg==show[i][y].bg)
						tmps[y]=show[i][y].ch,lastshow[i][y]=show[i][y],y++;
					//clrtm-=clock();
					SetColor(show[i][x].fg,show[i][x].bg);
					//clrtm+=clock();
					//gototm-=clock();
					gotoxy(i,x);
					//gototm+=clock();
					tmps[y]=0;
					//puttm-=clock();
					puts(tmps+x);
					//puttm+=clock();
				}
			}
			return ;
			fout<<"puttm "<<(double)(puttm)/CPS<<endl;
			fout<<"clrtm "<<(double)(clrtm)/CPS<<endl;
			fout<<"gototm "<<(double)(gototm)/CPS<<endl;
			fout<<"tottm "<<(double)(clock()-tm)/CPS<<endl;
			return ;
		}
		inline void EmptyShow(){
			memset(lastshow,0,sizeof(lastshow));
		}
	}
	using Output::EmptyShow;

	string curmap,lastmap,conads[10];
	int n=28,m=64,totp=1,sight,focusnpc,focusobj;
	bool quited,custom;
	int sta,plot,hadwp,hadab,rp;	//status,plot,weapons had,abilities had
	int mode,diff,bx[2],by[2];
	int score1,score2,maxscore;
#define STA_PEACE 0
#define STA_TALK 1
#define STA_FIGHT 2

#define PLOT_DIJ 1
#define PLOT_SPLAY 2
#define PLOT_DP 4
#define PLOT_KILL 8
#define PLOT_PRIM 16	//if primary is visited
#define PLOT_JUN 32
#define PLOT_SEN 64
#define PLOT_JYT 128
#define PLOT_JYB 256

#define MODE_SOLO 0
#define MODE_MATCH 1
#define MODE_FLAG 2
#define MODE_LAND 3
#define MODE_SOUL 4

#define DIFF_NORMAL 0
#define DIFF_HARD 1
#define DIFF_INSANE 2
	int scrx,scry;
	//���ڿ��� 30*128
	long begin_t;
#define TYP_WALL 1
#define TYP_TRAN 2

	const int totmod=2,totmap=6,totdif=3;

	int typ[N][M];
	const char MapName[][50]={
		"Dust2",
		"MOBA",
		"Lab",
		"Forest",
		"Church",
		"Luogu"
	};
	const char ModName[][50]={
		"SOLO",
		"�Ŷ�����",
		"����",
		"ռ��",
		"����ո�"
	};
	const char DifName[][50]={
		"Easy",
		"Hard",
		"Insane"
	};
	const char RnkName[][50]={
		"Newbie",
		"Pupil",
		"Specialist",
		"Expert",
		"Candidate Master",
		"Master",
		"International Master",
		"Grandmaster",
		"International Grandmaster"
		/*
		   [2600, inf) International Grandmaster �� 
		   [2200,2600) Grandmaster �� 
		   [2050,2200) International Master �� 
		   [1900,2050) Master �� 
		   [1700,1900) Candidate Master �� 
		   [1500,1700) Expert �� 
		   [1350,1500) Specialist �� 
		   [1200,1350) Pupil �� 
		   (-inf,1200) Newbie �� 
		 */
	};

	struct Trans{
		string s;
		int x,y;
		Trans(string a="",int b=0,int c=0){
			s=a;
			x=b,y=c;
		}
	}trans[N][M];

	int useF,useY;


	char conscr[50][140],conmp[N][M*2];
	bool see[N][M*2];
#define toX(x) (x)
#define toY(y) ((y)*2)
#define mp(x,y) mp[toX(x)][toY(y)]
#define Bey(x,y) (x<1||x>n||y<1||y>m)
	inline void GetCoord(double &x,double &y){
		x=MouseX-23;
		y=MouseY/2-33.5;
		x+=scrx;
		y+=scry/2.0;
	}
	inline void QuitGame(){
		Sleep(0.5*CPS);
		ShowCur();
		SetColor(Normal,BGnormal);
		fflush(stdin);
		fflush(stdout);
		quited=1;
		while(_kbhit()) _getch();
		//cin.ignore(1000000,'\n');
		_cls();
	}
	inline long double getdis(double a,double b,double c=0,double d=0){
		a=(a-c)*(a-c);
		b=(b-d)*(b-d);
		return sqrt(a+b);
	}
	inline void Fill(cN *s,const string &a,int fg=-1,int bg=-1){
		int ls=a.size();
		for(int i=0;i<ls;i++)
			s[i]+=cN(a[i],fg,bg);
	}
	inline void Fill(int x,int y,const int a,int fg=-1,int bg=-1){
		sprintf(tmps,"%d",a);
		Fill(&show[x][y],tmps,fg,bg);
	}
	inline void Fill(int x,int y,const string &a,int fg=-1,int bg=-1){
		Fill(&show[x][y],a,fg,bg);
	}
	int Fill(cN *s,int len,int x,int y1,int y2,const string &a,int fg=-1,int bg=-1){
		int y=y1;
		for(int i=0; i<a.size(); i++,y++){
			if(y>y2) s+=len,x++,y=y1;
			if(a[i]<0){	//Chinese
				if(y+1>y2) s+=len,x++,y=y1;
				s[y]+=cN(a[i],fg,bg);
				i++,y++;
			}
			s[y]+=cN(a[i],fg,bg);
		}
		return x;
	}
	int Fill(cN **s,int x,int y1,int y2,const string &a,int fg=-1,int bg=-1){
		if(s==(cN**)mp) return Fill(mp[x],sizeof(mp[0])/sizeof(cN),x,y1,y2,a,fg,bg);
		return -1;
	}
	int Fill(int x,int y1,int y2,const string &a,int fg=-1,int bg=-1){
		return Fill(show[x],sizeof(show[0])/sizeof(cN),x,y1,y2,a,fg,bg);
	}
	struct cdNode{
		long cd,nx;
		cdNode(long a=0,long b=0){
			cd=a,nx=b;
		}
		inline bool rea(){
			return clock()>=nx;
		}
		inline void act(){
			nx=clock()+cd;
		}
	};
	typedef cdNode CD;
	struct Button{
		int x,y1,y2;	//mp������
		string s,tp;
		int key;
		//  x y1 s tp key
		Button(int a=0,int b=0,string c="",string t="",int k=0){
			x=a,y1=b,y2=b+c.size()-1;
			s=c,tp=t,key=k;
		}
		/*
		   tp= Home wp    key = WP_TYPE
		   tp= Home ab    key = ABI_TYPE
		   tp= Arsenal wp key = WP_TYPE
		   tp= Arsenal ab key = ABI_TYPE
		   tp= computer
		 */
		inline bool Focus(){
			double px,py;
			GetCoord(px,py);
			px=toX(px),py=toY(py);
			//fout<<"x "<<x<<" y1 "<<y1<<" y2 "<<y2<<endl;
			//fout<<px<<" "<<py<<endl;
			return fabs(px-x)<=0.5&&y1<=py&&py<=y2;
		}
	};
	struct Flicker{
		long tm;
		cN *w,c;	// w mp
		Flicker(cN *a,long t=0,cN k=cN()){
			w=a,tm=t+clock(),c=k;
		}
	};
	struct Bullet{
		int tp,p,con,dmg,moon;	//contact 2^ 0~9
		double x,y,dx,dy,dis,spd;
		CD las,spin;
		cN ch;
		//         tp     p        x       y         dx         dy          dis        dmg      moon   ch
		Bullet(int t=0,int k=0,int a=0,int b=0,double c=0,double d=0,double dist=0,int atk=0,int m=0,cN e=cN()){
			tp=t,p=k,con=1<<k-1;
			x=a,y=b,dx=c,dy=d,spd=getdis(dx,dy);
			dis=dist,dmg=atk;
			moon=m,ch=e;
			las=CD(0.01*CPS,clock());
			spin=CD(0.2*CPS);
		}
	};
	struct Message{
		string s,name;
		Message(string a="",string b=""){
			s=a,name=b;
		}
	};
	queue<Button> quebut;
	queue<Flicker> queflc;
	queue<Bullet> quebul;
	stack<Message> stkmes;

	inline void SendMsg(const string &s,string w="System"){
		stkmes.push(Message(s,w));
	}

#define WP_DART 0
#define WP_SNIPER 1
#define WP_MINIGUN 2
#define WP_KATANA 3
#define WP_VSC 4
#define WP_SHIELD 5
#define WP_STAR 6
	const int totwp=7;
	const char WpnName[][50]={
		"Dart",
		"Sniper",
		"Minigun",
		"Katana",
		"VSC",
		"Holy Shield",
		"Starlight"
	};
	inline int getWpn(const string s){
		for(int i=0; i<7; i++)
			if(s==WpnName[i]) return i;
		fout<<"getWpn failed "<<s<<endl;
		return -1;
	}
	struct Weapon{
		int tp,dmg,am,full;
		double spd,dis;
		CD cd;
		long cd_r;
		bool R;
		int n,m;
		char img[10][20];
		string info;
		Weapon(int t=0,int a=0,double s=0,double d=0,int f=0,long c=0,long r=0){
			tp=t,dmg=a,spd=s,dis=d;
			am=full=f;
			cd=CD(c);
			cd_r=r;
			R=0;
		}
		inline void Init(int t=-1){
			if(t==-1) t=tp;
			//								dmg spd dis am CD     Re
			if(t==WP_DART)    *this=Weapon(t,15,12, 10, 1,0.5*CPS,999*CPS);
			if(t==WP_MINIGUN) *this=Weapon(t, 5,20, 50,20,0.1*CPS,1.5*CPS);
			if(t==WP_SNIPER)  *this=Weapon(t,24,50,100, 3,1.0*CPS,2.0*CPS);
			if(t==WP_KATANA)  *this=Weapon(t,25,12,  8, 3,0.5*CPS,1.5*CPS);
			if(t==WP_VSC)     *this=Weapon(t, 0,15,  8, 7,0.3*CPS,1.0*CPS);
			if(t==WP_SHIELD)  *this=Weapon(t, 0, 0,  0, 1,1.5*CPS,1.5*CPS);
			if(t==WP_STAR)    *this=Weapon(t,60, 0,100, 1,0.5*CPS,3.0*CPS);
			//dmg=700;
		}
		inline void GetInfo(){
			ifstream fin(((string)"./weapon/"+WpnName[tp]+".txt").c_str());
			fin.getline(tmps,10);
			sscanf(tmps,"%d%d",&n,&m);
			for(int i=0; i<=n+1; i++)
				fin.getline(img[i],20);
			getline(fin,info);
			fin.close();
		}
		inline void FillMap(int x,int y){	//Arsenal
			if(!n) return ;
			x-=n/2,y-=m/2;
			for(int i=1; i<=n; i++){
				string t;
				for(int j=1; j<=m; j++)
					t+=img[i][j];
				quebut.push(Button(x+i-1,y,t,"Arsenal wp",tp));
			}
		}
		inline void FillMap(){	//up
			if(!n) return ;
			int x=4,y=75;
			x-=n/2,y-=m/2;
			for(int i=1; i<=n; i++)
				for(int j=1; j<=m; j++)
					show[x+i-1][y+j-1]+=img[i][j];
		}
		inline void FillInfo(){
			for(int i=2; i<=6; i++)
				for(int j=5; j<=39; j++)
					show[i][j]=cN();
			Fill(2,6,WpnName[tp]);
			Fill(3,6,38,info);
		}
	}conwp[10];

#define ABI_RAID 0
#define ABI_RAGE 1
#define ABI_SHIELD 2
#define ABI_STRENG 3
#define ABI_HEAL 4
#define ABI_FLASH 5
#define ABI_CODE 6
#define ABI_SPFA 7
#define ABI_MOON 8
	const int totab=9;
	const char AbiName[][50]={
		"Raid",
		"Rage",
		"Shield",
		"Strengthen",
		"Heal",
		"Flash",
		"Code_Dance",
		"SPFA",
		"Moonlight"
	};
	inline int getAbi(const string s){
		for(int i=0; i<9; i++)
			if(s==AbiName[i]) return i;
		fout<<"getAbi failed "<<s<<endl;
		return -1;
	}
	struct Ability{
		int tp;
		CD cd;
		string info;
		Ability(int t=0,long c=0){
			tp=t;
			cd=CD(c);
		}
		inline void Init(int t=-1){
			if(t==-1) t=tp;
			if(t==ABI_RAID)   *this=Ability(t,6*CPS);
			if(t==ABI_RAGE)   *this=Ability(t,15*CPS);
			if(t==ABI_SHIELD) *this=Ability(t,5*CPS);
			if(t==ABI_STRENG) *this=Ability(t,3*CPS);
			if(t==ABI_HEAL)   *this=Ability(t,8*CPS);
			if(t==ABI_FLASH)  *this=Ability(t,15*CPS);
			if(t==ABI_CODE)   *this=Ability(t,10*CPS);
			if(t==ABI_SPFA)   *this=Ability(t,15*CPS);
			if(t==ABI_MOON)   *this=Ability(t,8*CPS);
			//*this=Ability(t,CPS);
		}
		inline void GetInfo(){
			ifstream fin(((string)"./ability/"+AbiName[tp]+".txt").c_str());
			if(!fin) return ;
			getline(fin,info);
			fin.close();
		}
		inline void FillInfo(){
			for(int i=2; i<=6; i++)
				for(int j=5; j<=39; j++)
					show[i][j]=cN();
			Fill(2,6,AbiName[tp]);
			Fill(3,6,38,info);
		}
		inline void FillMap(int x,int y){
			quebut.push(Button(x,y-2,"Click","Arsenal ab",tp));
		}
	}conab[10];

	struct Effect{
#define EFF_SPD 1
#define EFF_ATK 2
#define EFF_CD  3
#define EFF_VAM 4
#define EFF_STRENG 5
#define EFF_DEF 6
#define EFF_SHIELD 7
#define EFF_MOON 8
		int tp;
		long tm;
		double val;
		Effect(int k=0,double v=0,long t=-1){
			tp=k;
			if(~t) tm=clock()+t;
			else tm=0;
			val=v;
		}
		/*
		   spd %
		   atk %
		   cd %
		   vam %
		   STRENG val
		   def %
		   shield 
		   moon 
		 */
	};
	int totads;
	struct Ads{
		int x1,y1,x2,y2,pg,flc;
		CD cd,spin;
		Ads(int a=0,int b=0,int c=0,int d=0){
			x1=a,y1=b,x2=c,y2=d;
			pg=flc=0;
			cd=CD(5*CPS);
			spin=CD(0.2*CPS);
		}
		void FillMap(){
			//fout<<x1<<' '<<y1<<' '<<x2<<' '<<y2<<endl;
			string clr="rGbY";
			if(cd.rea()) pg=(pg+1)%5,cd.act();
			if(spin.rea()) flc=(flc+1)%4,spin.act();
			Fill((cN**)mp,x1+1,y1+2,y2-1,conads[pg]);
			int x=x2,y=y2,f=flc;
			for(int k=0; k<4; k++){
				mp[x][y]=cN();
				x+=DIRE[0][k],y+=DIRE[1][k];
				while(!(x==x1||x==x2)||!(y==y1||y==y2)){
					mp[x][y].ch=DIRE_CH[k];
					mp[x][y].fg=getFG(clr[f]);
					f=(f+1)%4;
					//fout<<"x "<<x<<" y "<<y<<endl;
					x+=DIRE[0][k],y+=DIRE[1][k];
				}
			}
			return ;
		}
	}ads[10];
	int totobj;
	struct objectNode{
		string name,info;
		int x,y,id;
		cN ch;
		objectNode(string st=""){
			if(st=="Splay") name="Soul of Splay";
			if(st=="Dij") name="Soul of Dij";
			if(st=="DP") name="Soul of DP";
		}
		void Init(int a,ifstream &fin){
			id=a;
			char c1,c2,c3;
			getline(fin,name);
			fin.getline(tmps,100);
			sscanf(tmps,"%d %d %c %c %c",&x,&y,&c1,&c2,&c3);
			/*
			   name
			   x y ch bg fg
			   info
			 */
			ch.Init(c1,c2,c3);
			getline(fin,info);
			return ;
		}
		void FillInfo(){
			for(int i=2; i<=6; i++)
				for(int j=5; j<=39; j++)
					show[i][j]=cN();
			Fill(2,6,name);
			Fill(4,6,39,info);
		}
	}obj[10];
	typedef objectNode oN;

	struct Player{	//player and enemies
#define px p[w].x
#define py p[w].y
		string name;
		cN ch;
		int id,dif,life,rating;
		bool dead,hos,combat;
		int x,y,dx,dy;	//���� [-1,1]
		int hp,maxhp;
		CD mv,ai;
		Weapon w1,w2;
		Ability abiQ,abiE;
		queue<oN> pack;
		queue<Effect> eff;
		double inatk,invam,inspd,indef,incd;
		int shield,moon,indmg;
		int see[N][M];
		inline void Init(int k,bool ho=0){
			id=k;
			ch=cN('@',White,BGgreen);
			dead=0;
			dx=1,dy=0;
			mv=CD(0.15*CPS);
			if(k==1){
				name=dat.name;
				rating=dat.rating;
				w1.Init(dat.w1);
				w2.Init(dat.w2);
				abiQ.Init(dat.abiQ);
				abiE.Init(dat.abiE);
			}else{
				if(name.empty()) name=GetRandName();
				while((w1.tp=rand()%totwp)==(w2.tp=rand()%totwp));
				w1.Init();
				w2.Init();
				while((abiQ.tp=rand()%totab)==(abiE.tp=rand()%totab));
				abiQ.Init();
				abiE.Init();
			}
			memset(see,0,sizeof(see));
			hos=ho;
			if(mode==MODE_SOLO) life=5;
			if(mode==MODE_MATCH) life=0;
			if(mode==MODE_SOUL) life=1;
			dif=diff;
			if(sta==STA_FIGHT){	//customize
				if(ho) ch=cN('E',White,BGred);
				else if(k>1) ch=cN('T',White,BGblue);
				x=bx[ho],y=by[ho];
			}
			if(dif==DIFF_NORMAL) ai=CD(0.5*CPS),maxhp=100;
			if(dif==DIFF_HARD)   ai=CD(0.1*CPS),maxhp=300;
			if(dif==DIFF_INSANE) ai=CD(0.01*CPS),maxhp=800;
			if(k==1) LockView();
			if(k==1&&~curmap.find("-bat")) maxhp=100;	//����
			hp=maxhp;
		}
		void Init(ifstream &fin,int k){
			getline(fin,name);
			fin.getline(tmps,100);
			char c1,c2,c3;
			sscanf(tmps,"%d %d %d %c %c %c",&diff,&x,&y,&c1,&c2,&c3);
			Init(k,1);
			ch.Init(c1,c2,c3);
			fin.getline(tmps,100),w1.Init(getWpn(tmps));
			fin.getline(tmps,100),w2.Init(getWpn(tmps));
			fin.getline(tmps,100),abiQ.Init(getAbi(tmps));
			fin.getline(tmps,100),abiE.Init(getAbi(tmps));
			/*
			   name
			   hp x y ch fg bg
			   w1
			   w2
			   q
			   e

			 */
		}
		void Respawn(){
			dead=0;
			hp=maxhp;
			w1.Init(w1.tp);
			w2.Init(w2.tp);
			abiQ.cd.nx=abiE.cd.nx=0;
			//while(!eff.empty()) eff.pop();
			eff.push(Effect(EFF_DEF,1,3*CPS));	//Invincible 3s
			if(mode==MODE_SOLO) while(typ[x=rand()%n+1][y=rand()%m+1]);
			if(mode==MODE_MATCH) x=bx[hos],y=by[hos];
			if(id==1) LockView();
			//while(1);
		}
		inline int GetSight(){
			return sight+(moon?40:0);
		}
		void GetSee(int sx=0,int sy=0,int st=0){	//Bfs ����
			memset(see,0,sizeof(see));
			queue<int> qx,qy,qz;
			qx.push(sx?sx:x);
			qy.push(sy?sy:y);
			qz.push(1);
			if(!st) st=GetSight();
			while(!qx.empty()){
				int x=qx.front(),y=qy.front(),d=qz.front()+1;
				qx.pop(),qy.pop(),qz.pop();
				if(d>st+1||see[x][y]) continue;
				see[x][y]=d;
				for(int i=0;i<4;i++){
					int nx=x+DIRE[0][i],ny=y+DIRE[1][i];
					if(Bey(nx,ny)||typ[nx][ny]) continue;
					qx.push(nx);
					qy.push(ny);
					qz.push(d);
				}
			}
		}
		inline void shift(){
			swap(w1,w2);
			if(!w1.R) w1.cd.act();
		}
		inline void Reload(){
			if(w1.am==w1.full) return ;
			w1.cd.nx=clock()+w1.cd_r;
			w1.R=1;
		}
		void SetMapPack(){
		}
		int GetHpCol(){
			if(hp>=0.8*maxhp) return Green;
			else if(hp>=0.3*maxhp) return Yellow;
			else if(hp>0) return Red;
			return -1;
		}
		inline void FillMap(){
			mp(x,y)=ch;
			if(sta==STA_PEACE) return ;
			int mx=toX(x),my=toY(y);
			if(shield||indef>0){
				mp[mx][my-2]=mp[mx][my+2]=cN('|',Yellow);
				mp[mx-1][my-1]=mp[mx-1][my+1]=cN('.',Yellow);
				mp[mx+1][my-1]=mp[mx+1][my+1]=cN('`',Yellow);
				mp[mx-1][my]=mp[mx+1][my]=cN('-',Yellow);
			}
			int cl=GetHpCol();
			if(hp<10) mp[mx-1][my]=cN(hp^48,cl);
			else if(hp>=100) sprintf(tmps,"%d",hp),Fill(&mp[mx-1][my-1],tmps,cl);
			else sprintf(tmps,"%d %d",hp/10,hp%10),Fill(&mp[mx-1][my-1],tmps,cl);
		}
		inline void GetBuff(){
			inatk=inspd=invam=indef=incd=indmg=shield=moon=0;
			int tot=eff.size();
			gt(tm);
			while(tot--){
				Effect e=eff.front();
				eff.pop();
				if(tm>e.tm) continue;
				if(e.tp==EFF_ATK) inatk+=e.val;
				if(e.tp==EFF_VAM) invam+=e.val;
				if(e.tp==EFF_SPD) inspd+=e.val;
				if(e.tp==EFF_CD)  incd+=e.val;
				if(e.tp==EFF_DEF) indef+=e.val;
				if(e.tp==EFF_SHIELD) shield=1;
				if(e.tp==EFF_STRENG) indmg+=e.val;
				if(e.tp==EFF_MOON) moon=1;
				eff.push(e);
			}
			if(w1.tp==WP_SHIELD) inspd+=0.2;
			indef=min(indef,1.0);
			mv.cd=0.15/(1+inspd)*CPS;
			abiQ.cd.cd=max(eps*CPS,(1-incd)*conab[abiQ.tp].cd.cd);
			abiE.cd.cd=max(eps*CPS,(1-incd)*conab[abiE.tp].cd.cd);
		}
		void EraseEff(int tp){
			int tot=eff.size();
			while(tot--){
				Effect e=eff.front();
				eff.pop();
				if(e.tp!=tp) eff.push(e);
			}
		}
	}p[11];

	namespace SplayTree{
		const int N=20;
		const int n=8,rt=9;
		int ch[N][2],fa[N],dep[N],wid[N],ext[N][2];
		char str[N],now[N],tar[N];
#define lc ch[u][0]
#define rc ch[u][1]

		/*

		   .[ ].
		//   \\
		//       \\
		[ ].       .[ ]
		\\     //
		.[ ] [ ]
		//
		// 
		// 
		[ ]    


		.[ ].
		//   \\
		//       \\
		//           \\
		//               \\
		[ ].               .[ ]
		\\             //
		[ ].       .[ ]
		\\     //
		[ ].[ ]
		\\
		[ ]




		.[ ].
		\\
		\\
		\\
		\\
		.[ ].
		//   \\
		//       \\
		//           \\
		//               \\
		[ ].               .[ ]
		\\             //
		[ ].       .[ ]
		\\      //
		[ ] [ ]

		 */
		inline bool Check(){
			return strcmp(now+1,tar+1)==0;
		}
		inline bool sn(int u){
			return ch[fa[u]][1]==u;
		}
		inline void rotate(int u){
			bool x=sn(u);
			int f=fa[u],ff=fa[f],v=ch[u][!x];
			ch[ff][sn(f)]=u,fa[u]=ff;
			ch[f][x]=v,fa[v]=f;
			ch[u][!x]=f,fa[f]=u;
		}
		int clk;
		void Dfs1(int u){
			now[++clk]=str[u];
			dep[u]=dep[fa[u]]+1;
			if(!lc&&!rc){
				wid[u]=ext[u][0]=ext[u][1]=0;
				return ;
			}
			if(lc) Dfs1(lc);
			if(rc) Dfs1(rc);
			if(lc&&rc){
				wid[u]=(ext[lc][1]+ext[rc][0])/2+1;
				wid[u]=max(wid[u],2);
				ext[u][0]=ext[lc][0]+wid[u];
				ext[u][1]=ext[rc][1]+wid[u];
			}else{
				wid[u]=2;
				if(lc){
					ext[u][0]=ext[lc][0]+2;
					ext[u][1]=ext[lc][1]-2;
				}else{
					ext[u][0]=ext[rc][0]-2;
					ext[u][1]=ext[rc][1]+2;
				}
				ext[u][0]=max(ext[u][0],0);
				ext[u][1]=max(ext[u][1],0);
			}
		}
		void Dfs2(int u,int x,int y){
			//mp[x][y-1].ch='['; mp[x][y].ch=str[u]; mp[x][y+1].ch=']';
			quebut.push(Button(x,y-1,(string)"["+str[u]+"]","SPLAY",u));
			for(int i=1;i<wid[u];i++){
				if(lc) mp[x+i][y-i*2].ch=mp[x+i][y-i*2-1].ch='/';
				if(rc) mp[x+i][y+i*2].ch=mp[x+i][y+i*2+1].ch='\\';
			}
			if(lc){
				//mp[x][y-2].ch='.';
				Dfs2(lc,x+wid[u],y-wid[u]*2);
			}
			if(rc){
				//mp[x][y+2].ch='.';
				Dfs2(rc,x+wid[u],y+wid[u]*2);
			}
			return ;
		}
		void FillMap(){	//from setmap
			Dfs2(ch[rt][0],4,32);
			Fill(&mp[3][14],tar+1);
			Fill(&mp[4][14],now+1);
			if(Check()) Fill(&mp[5][6],"opened!",Green);
		}
		void Gen(){
			memset(ch,0,sizeof(ch));
			static int t[N][2],all;
			ch[rt][0]=1;
			fa[1]=rt;
			for(int i=2; i<=n; i++){
				all=0;
				for(int j=1; j<i; j++){
					if(!ch[j][0]) t[all][0]=j,t[all][1]=0,all++;
					if(!ch[j][1]) t[all][0]=j,t[all][1]=1,all++;
				}
				int k=rand()%all;
				ch[t[k][0]][t[k][1]]=i;
				fa[i]=t[k][0];
			}
			for(int i=1; i<=n; i++)
				str[i]='0'+i;
			//for(int u=1; u<=n; u++) printf("%d lc %d rc %d fa %d\n",u,lc,rc,fa[u]);
			random_shuffle(str+1,str+n+1);
			clk=0;
			Dfs1(ch[rt][0]);
			memcpy(tar,now,sizeof(now));
			int lft=1000;
			while(lft--){
				int x=rand()%n+1;
				if(fa[x]!=rt) rotate(x);
			}
			clk=0;
			Dfs1(ch[rt][0]);
		}
		inline void Click(int x){
			if(fa[x]==rt) return ;
			rotate(x);
			clk=0;
			Dfs1(ch[rt][0]);
		}
		void Init(){
			Gen();
		}
#undef lc
#undef rc
	}

	namespace Mineswp{
		int n=16,m=30,tot;
		int b[N][M],vis[N][M];
		bool Gen(){
			memset(b,0,sizeof(b));
			int t[N*M][2],all;
			tot=60;
			while(tot--){
				//fout<<"tot "<<tot<<endl;
				all=0;
				for(int i=1; i<=n; i++)
					for(int j=1; j<=m; j++){
						if(b[i][j]==-1 || b[i][j]>5 || i+j<6 || i+j+6>n+m) continue;
						t[all][0]=i;
						t[all][1]=j;
						all++;
					}
				if(!all){
					for(int i=1; i<=n; i++)
						for(int j=1; j<=m; j++){
							if(b[i][j]==-1 || i+j<6 || i+j+6>n+m) continue;
							t[all][0]=i;
							t[all][1]=j;
							all++;
						}
					if(!all) return fout<<"Gen Failed"<<endl,0;
				}
				int k=rand()%all;
				int x=t[k][0],y=t[k][1];
				b[x][y]=-1;
				for(int i=-1; i<=1; i++)
					for(int j=-1; j<=1; j++)
						if(i|j&&~b[x+i][y+j]) b[x+i][y+j]++;
			}
			return 1;
		}
		void Init(){
			while(!Gen());
			memset(vis,0,sizeof(vis));
		}
		char toclr[]=" bGrBRgRN  ";
		void FillMap(){
			//return ;
			for(int i=1; i<=n; i++)
				for(int j=1; j<=m; j++){
					cN *ch=&mp(i,j);
					if(!vis[i][j]) (*ch)=cN('#',Yellow);//ch->bg=(ch-1)->bg=(ch+1)->bg=BGblue;
					else if(b[i][j]>0) *ch+=cN(b[i][j]+'0',getFG(toclr[b[i][j]]));
				}
			return ;
		}
		bool open(int x,int y){
			//return 1;
			if(Bey(x,y)) return 1;
			if(b[x][y]==-1) return 0;
			if(vis[x][y]) return 1;
			vis[x][y]=1;
			if(!b[x][y]){
				for(int i=-1; i<=1; i++)
					for(int j=-1; j<=1; j++)
						if(i|j) open(x+i,y+j);
			}
			return 1;
		}
	}
	int totnpc;
	struct NPCnode{
		string name;
		int x,y,id;
		cN ch;
		string info;
		void Init(int a,ifstream &fin){
			id=a;
			char c1,c2,c3;
			getline(fin,name);
			fin.getline(tmps,100);
			sscanf(tmps,"%d %d %c %c %c",&x,&y,&c1,&c2,&c3);
			/*
			   name
			   x y tot ch bg fg
			   info
			   q1
			   a1
			 */
			ch.Init(c1,c2,c3);
			getline(fin,info);
			return ;
		}
		void FillMap(){
			/*

			   o
			   -- --
			   / \

			 */
			int mx=toX(x),my=toY(y);
			mp[mx-1][my]+=cN('O',ch.fg);
			Fill(&mp[mx][my-2],"== ==",ch.fg);
			mp[mx][my]+=ch;
			mp[mx+1][my-1]+=cN('/',ch.fg,-1);
			mp[mx+1][my+1]+=cN('\\',ch.fg,-1);
		}
		void FillInfo(){
			for(int i=2; i<=6; i++)
				for(int j=5; j<=39; j++)
					show[i][j]=cN();
			Fill(2,6,name);
			Fill(4,6,39,info);
		}
	}npc[10];
	inline void LockView(){
		scrx=toX(p[1].x);
		scry=toY(p[1].y);
	}
	void ChangeMap(string s,int x,int y){
		if(s=="Training") return SendMsg("Training δ����");
		curmap=s;
		if(s==lastmap) lastmap.clear();
		if(curmap=="Primary" && !(plot&PLOT_KILL)) return ShowStory("Primary-0");
		if(curmap=="Primary" && !(plot&PLOT_PRIM)) return ChangeMap(s+"-bat",x,y);
		if(curmap=="Junior" && !(plot&PLOT_JUN)) return ChangeMap(s+"-bat",x,y);
		if(curmap=="Senior" && !(plot&PLOT_SEN)) return ChangeMap(s+"-bat",x,y);
		if(curmap=="Edu" && !(plot&PLOT_JYT)) return ChangeMap(s+"-bat",x,y);
		if(curmap=="Lab" && !(plot&PLOT_JYB)) return ChangeMap(s+"-bat",x,y);
		if(curmap=="Home" && plot&PLOT_SPLAY && plot&PLOT_DIJ && plot&PLOT_DP && !(plot&PLOT_KILL)){
			ShowStory("jyj-1");
			SlwPrt("Press:");
			SlwPrt("0: ����  1: ������  ");
			do RenewKeyboard();
			while(!KB_DOWN('0')&&!KB_DOWN('1'));
			if(KB_DOWN('0')) ShowStory("jyj-1-0");
			else ShowStory("jyj-1-1");
			return ChangeMap("Home-bat",x,y);
		}
		s="./map-plot/"+s+".txt";
		EncryptF(s.c_str());
		ifstream fin(s.c_str());
		while(!quebul.empty()) quebul.pop();
		while(!queflc.empty()) queflc.pop();
		//	n,m
		fin.getline(tmps,100);
		sscanf(tmps,"%d%d",&n,&m);
		//	map
		memset(conmp,0,sizeof(conmp));
		for(int i=0; i<=n+1; i++)
			fin.getline(conmp[i],M*2);
		fin.getline(tmps,2);
		//	typ
		memset(typ,0,sizeof(typ));
		totads=0;
		for(int i=0; i<=n+1; i++){
			fin.getline(tmps,M*2);
			for(int j=0; j<=m+1; j++){
				char c=tmps[j*2];
				if(c=='#'||c=='A') typ[i][j]=TYP_WALL;
				if(c=='T') typ[i][j]=TYP_TRAN;
			}
			for(int j=1; j<=toY(m); j++)
				if(tmps[j]=='A'){
					int w=0;
					for(int k=1; k<=totads; k++)
						if(ads[k].x2==i-1&&ads[k].y1==j) w=k;
					//fout<<"find A w "<<w<<endl;
					if(w) ads[w].x2++,j=ads[w].y2;
					else{
						w=j;
						while(tmps[j+1]=='A') j++;
						ads[++totads]=Ads(i,w,i,j);
						//fout<<"New ad "<<i<<' '<<w<<' '<<j<<endl;
					}
				}
		}
		fin.getline(tmps,2);
		//	npc
		fin>>totnpc;
		fin.ignore();
		for(int i=1; i<=totnpc; i++)
			npc[i].Init(i,fin);
		//	obj
		fin>>totobj;
		fin.ignore();
		for(int i=1; i<=totobj; i++)
			obj[i].Init(i,fin);
		//	trans
		int tot;
		fin>>tot;
		fin.ignore();
		while(tot--){	//������
			int a,b,c,d,x,y;
			string s;
			fin>>a>>b>>c>>d>>s>>x>>y;
			for(int i=a; i<=c; i++)
				for(int j=b; j<=d; j++)
					trans[i][j]=Trans(s,x,y);
			//fout<<"trans "<<s<<endl; fout<<x<<' '<<y<<endl;
		}
		totp=1;
		bool bt=0;
		if(~curmap.find("-bat")){
			bt=1;
			if(curmap=="Mines-bat" && plot&PLOT_DIJ) bt=0;
			if(curmap=="Forest-bat" && plot&PLOT_SPLAY) bt=0;
		}
		if(bt){
			fin>>tot;
			fin.ignore(1000,'\n');
			mode=MODE_SOLO;
			maxscore=5;
			while(tot--){
				totp++;
				p[totp].Init(fin,totp);
			}
			if(curmap=="Mines-bat") ShowStory("Dij-1");
			if(curmap=="Forest-bat") ShowStory("Splay-1");
			if(curmap=="Primary-bat") ShowStory("Primary-1");
			if(curmap=="Junior-bat") ShowStory("Junior-1");
			if(curmap=="Senior-bat") ShowStory("Senior-1");
			if(curmap=="Edu-bat") ShowStory("Edu-1");
			if(curmap=="Lab-bat") ShowStory("Lab-1");
			puts("Ready");
			Sleep(1*CPS);
			puts("Set");
			Sleep(1*CPS);
			puts("Fight!");
			Sleep(1*CPS);
			sta=STA_FIGHT;
			if(mode==MODE_SOLO){
				p[1].life=p[2].life=5;
			}
		}
		fin.close();
		EncryptF(s.c_str());
		if(curmap=="Mines") Mineswp::Init();
		if(curmap=="Forest") SplayTree::Init();
		if(curmap=="Factory"){
			int tot=p[1].pack.size();
			for(int i=0; i<p[1].pack.size(); i++){
				if(plot&PLOT_SPLAY && plot&PLOT_DIJ && plot&PLOT_DP) break;
				oN o=p[1].pack.front();
				p[1].pack.pop();
				if(o.name=="Soul of Splay"){
					ShowStory("Splay-3");
					plot|=PLOT_SPLAY;
					rp+=10000;
				}else if(o.name=="Soul of Dij"){
					ShowStory("Dij-3");
					plot|=PLOT_DIJ;
					plot|=PLOT_DP;	//update
					rp+=10000;
				}else if(o.name=="Soul of DP"){
					ShowStory("DP-3");
					plot|=PLOT_DP;
				}else p[1].pack.push(o);
				SaveGame();
				if(plot&PLOT_SPLAY && plot&PLOT_DIJ && plot&PLOT_DP) ShowStory("Factory-1");
			}
		}
		if(curmap=="Home") SaveGame();
		if(curmap=="Mines") SendMsg("����ɨ�ף��ƶ���δ�򿪵ĸ����൱�ڵ㿪�����ǲ��ܱ�ǡ�","����");
		/*
		   fout<<"ChangeMap "<<s<<endl;
		   fout<<n<<" "<<m<<endl;
		   for(int i=0; i<=n+1; i++)
		   fout<<conmp[i]<<endl;
		 */
		p[1].x=x;
		p[1].y=y;
		LockView();
		/*
		   n m

		   map

		   typ

		   totnpc
		   npc
		   totobj
		   obj
		   tot   --trans
		   trans
		   (totene)
		   name
		   hp x y
		   wp1
		   wp2
		   ab1
		   ab2
		 */
	}

	void LoadMap(){
		totads=totnpc=totobj=0;
		ifstream fin(("./map-cus/"+curmap+".txt").c_str());
		//	n,m
		fin.getline(tmps,100);
		sscanf(tmps,"%d%d",&n,&m);
		//	map
		memset(conmp,0,sizeof(conmp));
		for(int i=0; i<=n+1; i++)
			fin.getline(conmp[i],M*2);
		fin.getline(tmps,2);
		//	typ
		memset(typ,0,sizeof(typ));
		for(int i=0; i<=n+1; i++){
			fin.getline(tmps,M*2);
			for(int j=0; j<=m+1; j++){
				char c=tmps[j*2];
				if(c=='#') typ[i][j]=TYP_WALL;
			}
		}
		fin.getline(tmps,2);
		fin>>bx[0]>>by[0]>>bx[1]>>by[1];
		fin.close();
		//fout<<"bx0 "<<bx[0]<<endl;
	}
	inline void ChangeMap(Trans t){
		ChangeMap(t.s,t.x,t.y);
	}
	inline void Die(int w){
		p[w].dead=1;
		p[w].mv.nx=clock()+5*CPS;
		if(w==1) ChangeMap("Home",10,10);
	}
	int getene[15],desx[15],desy[15];
	inline bool FindEne(int w){
		*getene=0;
		for(int i=1; i<=totp; i++)
			if(p[i].hos!=p[w].hos&&p[w].see[p[i].x][p[i].y]) getene[++*getene]=i;
		return *getene;
	}
	inline void SetDes(int w){
		if(p[w].hp<0.2*p[w].maxhp&&*getene){
			int nx=px-p[getene[1]].x,ny=py-p[getene[1]].y;
			if(nx<0) nx=-1;
			if(nx>0) nx=1;
			if(ny<0) ny=-1;
			if(ny>0) ny=1;
			desx[w]=px+nx;
			desy[w]=py+ny;
			if(typ[desx[w]][desy[w]]){
				if(!typ[px][py+ny]) desx[w]-=nx;
				else if(!typ[px+nx][py]) desy[w]-=ny;
				else desx[w]=px,desy[w]=py;
			}
		}else{
			while(typ[desx[w]=rand()%n+1][desy[w]=rand()%m+1]);
		}
		//fout<<w<<" desx "<<desx[w]<<" desy "<<desy[w]<<endl;
	}
	inline void GotoDes(int w){
		if(Bey(desx[w],desy[w])||typ[desx[w]][desy[w]]||px==desx[w]&&py==desy[w]) SetDes(w);
		p[w].GetSee(desx[w],desy[w],INF);
		int k=-1,mindis=INF;
		for(int i=0; i<4; i++){
			int x=px+DIRE[0][i],y=py+DIRE[1][i];
			if(Bey(x,y)||typ[x][y]) continue;
			int d=p[w].see[x][y];
			if(mindis>d) mindis=d,k=i;
			else if(mindis==d&&rand()&1) k=i; 
		}
		if(~k) Move(DIRE[0][k],DIRE[1][k],w);
	}
	inline void RunAway(int w){
		p[w].GetSee(desx[w],desy[w],INF);
		int k=-1,maxdis=0;
		for(int i=0; i<4; i++){
			int x=px+DIRE[0][i],y=py+DIRE[1][i];
			if(Bey(x,y)||typ[x][y]) continue;
			int d=p[w].see[x][y];
			if(maxdis<d) maxdis=d,k=i;
			else if(maxdis==d&&rand()&1) k=i; 
		}
		if(~k) Move(DIRE[0][k],DIRE[1][k],w);
	}
	inline void Winner(){
		if(custom){
			_cls();
			puts("You win!");
			puts("");
			puts("");
			puts("");
			puts("Press Enter to be continued...");
			do RenewKeyboard();
			while(!KB_DOWN(VK_RETURN));
			QuitGame();
			return ;
		}
		if(lastmap=="Netbar"){
			sta=STA_PEACE;
			ChangeMap(lastmap,6,10);
			p[1].Init(1);
			_cls();
			gotoxy(1,1);
			if(diff==DIFF_NORMAL){
				rp+=10;
				puts("������10rp");
			}
			if(diff==DIFF_HARD){
				rp+=25;
				puts("������25rp");
			}
			if(diff==DIFF_INSANE){
				rp+=50;
				puts("������50rp");
			}
			SaveGame();
			do RenewKeyboard();
			while(!KB_DOWN(VK_RETURN));
			return ;
		}
		//plot
		totp--;
		sta=STA_PEACE;
		p[1].Init(1);
		if(curmap=="Forest-bat"){
			ShowStory("Splay-2");
			p[1].pack.push(oN("Splay"));
		}
		if(curmap=="Mines-bat"){
			ShowStory("Dij-2");
			p[1].pack.push(oN("Dij"));
		}
		if(curmap=="Home-bat"){
			ShowStory("jyj-2");
			plot|=PLOT_KILL;
			ChangeMap("Home",p[1].x,p[1].y);
		}
		if(curmap=="Primary-bat"){
			ShowStory("Primary-2");
			plot|=PLOT_PRIM;
			ChangeMap("Primary",p[1].x,p[1].y);
		}
		if(curmap=="Junior-bat"){
			ShowStory("Junior-2");
			plot|=PLOT_JUN;
			ChangeMap("Junior",p[1].x,p[1].y);
		}
		if(curmap=="Senior-bat"){
			ShowStory("Senior-2");
			plot|=PLOT_SEN;
			ChangeMap("Senior",p[1].x,p[1].y);
		}
		if(curmap=="Edu-bat"){
			ShowStory("Edu-2");
			plot|=PLOT_JYT;
			ChangeMap("Edu",p[1].x,p[1].y);
		}
		if(curmap=="Lab-bat"){
			ShowStory("Lab-2");
			ShowStory("End");
			plot|=PLOT_JYB;
			SaveGame();
			QuitGame();
		}
		SaveGame();
	}
	inline void Loser(){
		_cls();
		gotoxy(1,1);
		puts("�㱻��ɱ��");
		puts("");
		puts("");
		puts("");
		puts("Press Enter to be continued...");
		do RenewKeyboard();
		while(!KB_DOWN(VK_RETURN));
		if(lastmap=="Netbar"){
			sta=STA_PEACE;
			ChangeMap(lastmap,6,10);
			p[1].Init(1);
			return ;
		}
		QuitGame();	//custom
	}
	inline void Kill(int slayer,int dead){
		if(dead==1) sprintf(tmps,"You have been slain by %s",p[slayer].name.c_str());
		else if(slayer==1) sprintf(tmps,"You have slain %s",p[dead].name.c_str());
		else sprintf(tmps,"Player %s have been slain by %s",p[dead].name.c_str(),p[slayer].name.c_str());
		SendMsg(tmps);
		if(mode==MODE_SOLO){
			p[dead].life--;
		}
		if(mode==MODE_MATCH){
			p[slayer].life++;
		}
		p[dead].dead=1;
		p[dead].mv.nx=clock()+5*CPS;
	}
	inline void Attack(int p1,int p2,int dmg){
		if(p[p2].dead) return ;
		dmg=(dmg+p[p1].indmg)*(1+p[p1].inatk)*(1-p[p2].indef)+0.5;
		dmg=min(dmg,p[p2].hp);
		if(p[p2].shield){
			if(p[p2].hp<=dmg){
				if(p[p2].abiQ.tp==ABI_SHIELD) p[p2].abiQ.cd.nx=0;
				if(p[p2].abiE.tp==ABI_SHIELD) p[p2].abiE.cd.nx=0;
			}
			return p[p2].EraseEff(EFF_SHIELD);
		}
		p[p2].hp-=dmg;
		p[p1].hp=min(p[p1].maxhp,p[p1].hp+(int)(dmg*p[p1].invam+0.5));
		if(p[p1].indmg) p[p1].EraseEff(EFF_STRENG);
		if(p[p2].hp<=0) return Kill(p1,p2);
	}
	inline void ActAbi(int w,Ability &abi,double posx=0,double posy=0){
		if(curmap=="Mines") return ;
		static bool dmgd[N][M];
		gt(tm);
		if(!abi.cd.rea()) return ;
		abi.cd.act();
		if(abi.tp==ABI_RAGE){
			p[w].hp=p[w].hp+1>>1;
			p[w].eff.push(Effect(EFF_ATK,1,5*CPS));
			p[w].eff.push(Effect(EFF_VAM,0.5,5*CPS));
			return ;
		}
		if(abi.tp==ABI_HEAL){
			for(int i=1; i<=totp; i++)
				if(p[i].hos==p[w].hos&&getdis(px,py,p[i].x,p[i].y)<=8)
					p[i].hp=min(p[i].hp+(int)(0.35*p[i].maxhp+0.5),p[i].maxhp);
			return ;
		}
		if(abi.tp==ABI_SHIELD){
			p[w].eff.push(Effect(EFF_SHIELD,0,0.75*CPS));
			return ;
		}
		if(abi.tp==ABI_STRENG){
			p[w].eff.push(Effect(EFF_STRENG,20,5*CPS));
			return ;
		}
		if(abi.tp==ABI_MOON){
			p[w].eff.push(Effect(EFF_MOON,0,5*CPS));
			return ;
		}
		if(w==1) GetCoord(posx,posy);
		double relx=posx-px,rely=posy-py,dis=getdis(relx,rely);
		if(dis<eps) return ;
		if(abi.tp==ABI_RAID){
			relx*=0.1/dis;
			rely*=0.1/dis;
			dis=min(dis,6.0);
			int x=px,y=py;
			double nx=x,ny=y;
			memset(dmgd,0,sizeof(dmgd));
			while(!Bey(x,y)&&!typ[x][y]){
				dmgd[x][y]=1;
				nx+=relx,ny+=rely;
				dis-=getdis(relx,rely);
				if(dis<0) break;
				x=nx+0.5,y=ny+0.5;
			}
			nx-=relx,ny-=rely;
			x=nx+0.5,y=ny+0.5;
			for(int i=min(x,px);i<=max(x,p[w].x);i++)
				for(int j=min(y,py);j<=max(y,p[w].y);j++)
					if(dmgd[i][j]) queflc.push(Flicker(&mp(i,j),0.15*CPS,cN('X',Red,-1)));//,fout<<i<<' '<<j<<endl;
			for(int i=1; i<=totp; i++)
				if(i!=w&&dmgd[p[i].x][p[i].y]) Attack(w,i,20);
			px=x,py=y;
		}
		if(abi.tp==ABI_FLASH){
			double nx=px+relx*min(dis,12.0)/dis,ny=py+rely*min(dis,12.0)/dis;
			int x=nx+0.5,y=ny+0.5;
			relx*=0.1/dis;
			rely*=0.1/dis;
			while(Bey(x,y)||typ[x][y]){
				nx-=relx,ny-=rely;
				x=nx+0.5,y=ny+0.5;
			}
			px=x,py=y;
		}
		return ;
	}
	inline void Move(int nx,int ny,int w=1){
		gt(tm);
		if(!p[w].mv.rea()) return ;
		if(nx>0) nx=1;
		else if(nx<0) nx=-1;
		if(ny>0) ny=1;
		else if(ny<0) ny=-1;
		if(!nx&&!ny) return;
		p[w].dx=nx;
		p[w].dy=ny;
		nx+=px;
		ny+=py;
		if(typ[nx][ny]==TYP_TRAN&&sta!=STA_FIGHT)
			return p[w].mv.nx=tm+0.5*CPS,ChangeMap(trans[nx][ny]);
		if(Bey(nx,ny)||typ[nx][ny]==TYP_WALL) return ;
		p[w].mv.act();
		px=nx,py=ny;
	}
	inline void Fire(int w,double relx,double rely){
		gt(tm);
		Weapon &wp=p[w].w1;
		if(!wp.cd.rea()) return ;
		wp.cd.act();
		if(wp.tp==WP_SHIELD){
			p[w].eff.push(Effect(EFF_DEF,0.75,0.5*CPS));
			wp.am=0;
			p[w].Reload();
			return ;
		}
		relx-=px;
		rely-=py;
		if(abs(relx)<eps&&abs(rely)<eps) rely=1;
		double d=getdis(relx,rely);
		static bool dmgd[N][M];
		if(wp.tp==WP_KATANA&&wp.am<3){
			bool hit=0;
			if(wp.am==2){
				double dis=max(min(d-1,3.0),eps);
				double nx=px+relx*min(dis,d)/d,ny=py+rely*min(dis,d)/d;
				relx*=0.1/d,rely*=0.1/d;
				int x=nx+0.5,y=ny+0.5;
				while(Bey(x,y)||typ[x][y]){	//Flash
					nx-=relx,ny-=rely;
					x=nx+0.5,y=ny+0.5;
				}
				nx-=relx,ny-=rely;
				x=nx+0.5,y=ny+0.5;
				memset(dmgd,0,sizeof(dmgd));
				px=x,py=y;

				dis=wp.dis;
				nx=x,ny=y;
				while(!Bey(x,y)&&!typ[x][y]){
					dmgd[x][y]=1;
					nx+=relx,ny+=rely;
					dis-=getdis(relx,rely);
					if(dis<0) break;
					x=nx+0.5,y=ny+0.5;
				}
				for(int i=min(x,px);i<=max(x,px);i++)
					for(int j=min(y,py);j<=max(y,py);j++)
						if(dmgd[i][j]) queflc.push(Flicker(&mp(i,j),0.15*CPS,cN('*',Red,-1)));
				for(int i=1; i<=totp; i++)
					if(p[i].hos!=p[w].hos&&dmgd[p[i].x][p[i].y]) Attack(w,i,35),hit=1;
			}else{
				for(int i=px-4; i<=px+4; i++)
					for(int j=py-4; j<=py+4; j++){
						dmgd[i][j]=(!Bey(i,j)&&!typ[i][j]&&getdis(i,j,px,py)<=4);
						if(dmgd[i][j]) queflc.push(Flicker(&mp(i,j),0.15*CPS,cN('*',Red,-1)));
					}
				for(int i=1; i<=totp; i++)
					if(p[i].hos!=p[w].hos&&dmgd[p[i].x][p[i].y]) Attack(w,i,45),hit=1;
			}
			if(hit){
				if(p[w].abiQ.tp==ABI_RAID) p[w].abiQ.cd.nx=0;
				if(p[w].abiE.tp==ABI_RAID) p[w].abiE.cd.nx=0;
			}
			wp.am--;
		}else if(wp.tp==WP_STAR){
			memset(dmgd,0,sizeof(dmgd));
			double nx=px,ny=py;
			relx*=0.1/d;
			rely*=0.1/d;
			int x=nx,y=ny;
			while(!Bey(x,y)){
				nx+=relx,ny+=rely;
				x=nx+0.5,y=ny+0.5;
				dmgd[x][y]=1;
			}
			for(int i=1; i<=n; i++)
				for(int j=1; j<=m; j++)
					if(dmgd[i][j]){
						cN *k=&mp(i,j);
						if(p[w].moon){
							queflc.push(Flicker(k  ,0.3*CPS,cN(-1,-1,rand()&1?BGyellow:BGwhite)));
							if(dmgd[i][j-1]) queflc.push(Flicker(k-1,0.5*CPS,cN(-1,-1,rand()&1?BGyellow:BGwhite)));
							if(dmgd[i][j+1]) queflc.push(Flicker(k+1,0.5*CPS,cN(-1,-1,rand()&1?BGyellow:BGwhite)));
						}else{
							queflc.push(Flicker(k  ,0.3*CPS,cN(-1,-1,BGyellow)));
							if(dmgd[i][j-1]) queflc.push(Flicker(k-1,0.5*CPS,cN(-1,-1,BGyellow)));
							if(dmgd[i][j+1]) queflc.push(Flicker(k+1,0.5*CPS,cN(-1,-1,BGyellow)));
						}
					}
			for(int i=1; i<=totp; i++)
				if(p[i].hos!=p[w].hos&&dmgd[p[i].x][p[i].y])
					Attack(w,i,wp.dmg+(p[w].moon?(int)(0.15*p[i].hp+0.1*p[i].maxhp+0.5):0));
			wp.am--;
			if(p[w].moon) p[w].EraseEff(EFF_MOON);
		}else{
			relx*=wp.spd/d;
			rely*=wp.spd/d;
			wp.am--;
			if(wp.tp==WP_DART) d=min(d,wp.dis);
			else d=wp.dis;
			cN ch;
			if(wp.tp==WP_DART) ch=cN('+',White,-1);
			if(wp.tp==WP_MINIGUN) ch=cN('*',Yellow,-1);
			if(wp.tp==WP_SNIPER) ch=cN('o',Green,-1);
			if(wp.tp==WP_KATANA) ch=cN('K',Red,-1);
			if(wp.tp==WP_VSC) wp.dmg=rand()%26+1,ch=cN(wp.dmg+'a'-1,Yellow,-1);
			quebul.push(Bullet(wp.tp,w,px,py,relx,rely,d,wp.dmg,p[w].moon&&wp.tp!=WP_DART,ch));
			if(p[w].moon&&wp.tp!=WP_DART) p[w].EraseEff(EFF_MOON);
		}
		if(!wp.am) p[w].Reload();
	}

	void SetMapNormal(){
		for(int i=0;i<=n+1;i++)
			for(int j=0;j<=toY(m+1);j++)
				mp[i][j]=cN(conmp[i][j]);
		for(int i=1; i<=40; i++)
			for(int j=1; j<=135; j++)
				show[i][j]=cN(conscr[i][j]);
		gt(tm);
		p[1].GetSee();
		memset(see,0,sizeof(see));
		for(int k=1; k<=totp; k++)
			if(!p[k].hos){
				p[k].GetSee();
				for(int i=1; i<=n; i++)
					for(int j=1; j<=m; j++)
						if(p[k].see[i][j]) see[toX(i)][toY(j)]=1;
			}
		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++){
				if(typ[i][j]||!see[toX(i)][toY(j)]) continue;
				for(int k=0; k<4; k++){
					int x=i+DIRE[0][k],y=j+DIRE[1][k];
					if(typ[x][y]||Bey(x,y)||see[toX(x)][toY(y)]) continue;
					mp(i,j)=cN('.',Yellow);
					break;
				}
			}
		for(int i=0;i<=n+1;i++)
			for(int j=0;j<=m+1<<1;j++)
				if(conmp[i][j]!=' ') mp[i][j].ch=conmp[i][j];
		if(curmap=="Home"){
			for(int i=0; i<totwp; i++){
				if(!(hadwp&1<<i)) continue;
				string s="           ";
				int l=(s.size()-strlen(WpnName[i])+1)/2;
				for(int j=0; WpnName[i][j]; j++)
					s[j+l]=WpnName[i][j];
				quebut.push(Button(3+i,29,s,"Home wp",i));
			}
			mp[3+p[1].w1.tp][27].ch='$';
			mp[3+p[1].w2.tp][27].ch='$';
			for(int i=0; i<totab; i++){
				if(!(hadab&1<<i)) continue;
				string s="          ";
				int l=(s.size()-strlen(AbiName[i])+1)/2;
				for(int j=0; AbiName[i][j]; j++)
					s[j+l]=AbiName[i][j];
				quebut.push(Button(3+i,4,s,"Home ab",i));
			}
			mp[3+p[1].abiQ.tp][2].ch='$';
			mp[3+p[1].abiE.tp][2].ch='$';
		}
		if(curmap=="Arsenal"){
			if(!(hadwp&1<<WP_KATANA)) conwp[WP_KATANA].FillMap(11,11);
			if(!(hadwp&1<<WP_VSC))    conwp[WP_VSC].   FillMap(11,24);
			if(!(hadwp&1<<WP_SHIELD)) conwp[WP_SHIELD].FillMap(11,37);
			if(!(hadwp&1<<WP_STAR))   conwp[WP_STAR].  FillMap(11,50);

			if(!(hadab&1<<ABI_FLASH)) conab[ABI_FLASH].FillMap(26,11);
			if(!(hadab&1<<ABI_CODE))  conab[ABI_CODE]. FillMap(26,24);
			if(!(hadab&1<<ABI_SPFA))  conab[ABI_SPFA]. FillMap(26,37);
			if(!(hadab&1<<ABI_MOON))  conab[ABI_MOON]. FillMap(26,50);
		}
		if(curmap=="Netbar"){
			quebut.push(Button(10,8,"   KDOJ   ","computer"));
			quebut.push(Button(14,8,"Codeforces","computer"));
			quebut.push(Button(18,8," darkbzoj ","computer"));
			quebut.push(Button(10,26,"  Luogu  ","computer"));
			quebut.push(Button(14,26," AtCoder ","computer"));
			quebut.push(Button(18,26,"   UOJ   ","computer"));
		}
		if(curmap=="Forest") SplayTree::FillMap();
		if(curmap=="Mines") Mineswp::FillMap();
		int tot=queflc.size();
		while(tot--){	//��ʾ��Ч
			Flicker f=queflc.front();
			queflc.pop();
			queflc.push(f);
			cN *w=f.w;
			//int x=(w-mp[0])/(sizeof(mp[0])/sizeof(cN)); int y=(w-mp[0])%(sizeof(mp[0])/sizeof(cN)); if(see[x][y])
			*w+=f.c;
		}
		tot=quebul.size();
		while(tot--){
			Bullet b=quebul.front();
			quebul.pop();
			int x=b.x+0.5,y=b.y+0.5;
			cN *k=&mp(x,y);
			*k+=b.ch;
			if(b.moon){
				int t=queflc.size();
				while(t--){
					Flicker f=queflc.front();
					queflc.pop();
					if(f.w==k){
						t=1;
						break;
					}
				}
				if(t!=1) queflc.push(Flicker(k,0.5*CPS,cN(-1,-1,BGwhite)));
			}
			quebul.push(b);
		}
		tot=quebut.size();
		while(tot--){	//��ť
			Button b=quebut.front();
			quebut.pop();
			Fill(&mp[b.x][b.y1],b.s);
			quebut.push(b);
		}
		for(int i=1;i<=totp;i++){	//��
			if(!see[toX(p[i].x)][toY(p[i].y)]) continue;
			if(p[i].dead) continue;
			p[i].FillMap();
		}
		for(int i=1;i<=totnpc;i++)	//NPC
			npc[i].FillMap();
		for(int i=1;i<=totobj;i++){	//obj
			int x=obj[i].x,y=obj[i].y;
			mp(x,y)+=obj[i].ch;
		}
		for(int i=1;i<=totads;i++)	//ads
			ads[i].FillMap();
		/*
		   int mx=toX(p[1].x)+p[1].dx,my=toY(p[1].y)+p[1].dy;
		   mp[mx][my].ch=DIRE_CH[getDir(p[1].dx,p[1].dy)];	//����
		   mp[mx][my].setFG(Green);
		 */
		for(int i=8; i<38; i++)	//mp��showת��
			for(int j=5; j<132; j++){
				int x=scrx+i-23,y=scry+j-68;
				if(x<0||x>n+1||y<0||y>toY(m+1)) show[i][j]=cN();
				else show[i][j]=mp[x][y];
			}
		return ;
	}

	inline void SetBasicInfo(){	//RenewMap
		gt(tm);
		//��Ϣ
		int tot=stkmes.size();
		int mx,my;
		stack<Message> tmp;
		mx=2;
		for(int i=0; i<tot; i++){
			const Message s=stkmes.top();
			stkmes.pop();
			if(i>3) continue;
			tmp.push(s);
			mx=Fill(mx,85,131,s.name+": "+s.s)+1;
			if(!i) mx++;
		}
		while(!tmp.empty())
			stkmes.push(tmp.top()),tmp.pop();
		//����CD
		double left;
		Fill(3,45,AbiName[p[1].abiQ.tp]);
		Fill(5,45,AbiName[p[1].abiE.tp]);
		if(!p[1].abiQ.cd.rea()){
			left=(double)(p[1].abiQ.cd.nx-tm)/CPS;
			mx=3,my=42;
			if(left>=10) Fill(mx,my-1,(int)(left));
			else if(left>=1) show[mx][my]=cN((int)(left)^48,Normal);
			else{
				sprintf(tmps,"%.1f",left);
				Fill(mx,my-1,tmps);
			}
		}
		if(!p[1].abiE.cd.rea()){
			left=(double)(p[1].abiE.cd.nx-tm)/CPS;
			mx=5,my=42;
			if(left>=10) Fill(mx,my-1,(int)(ceil(left)));
			else if(left>=1) show[mx][my]=cN((int)(ceil(left))^48,Normal);
			else{
				sprintf(tmps,"%.1f",left);
				Fill(mx,my-1,tmps);
			}
		}
		//���Ͻ�
		Fill(2,6,dat.name);
		Fill(4,11,rp);	//rp
		int hpcol=p[1].GetHpCol();
		if(~hpcol) Fill(3,34,p[1].hp,hpcol);	//hp
		for(int i=0;i<(int)(20.0*p[1].hp/p[1].maxhp+0.5);i++) show[3][i+11].fg=hpcol;
		Fill(5,13,sight);
		Fill(6,11,curmap);
		//Fill(6,36,plot);
		if(sta==STA_PEACE) Fill(6,28,"Peace",Green);
		if(sta==STA_FIGHT){	//score
			Fill(6,28,"Fight",Red);
			for(int i=8; i<=11; i++)
				for(int j=5; j<=30; j++)
					show[i][j]=cN();
			for(int i=5; i<=29; i++)
				show[11][i].ch='-';
			for(int i=8; i<=10; i++)
				show[i][30].ch='|';
			show[11][30]='+';
			Fill(8,6,ModName[mode]);
			string s="> ";
			if(score1<10) s+=(char)(score1+'0'),s+=' ';
			else s+=(char)(score1/10+'0'),s+=(char)(score1%10+'0');
			for(int i=0; i<(int)(20.0*score1/maxscore+0.5); i++)
				s+="=";
			Fill(9,5,s,Lblue);
			s="> ";
			if(score2<10) s+=(char)(score2+'0'),s+=' ';
			else s+=(char)(score2/10+'0'),s+=(char)(score2%10+'0');
			for(int i=0; i<(int)(20.0*score2/maxscore+0.5); i++)
				s+="=";
			Fill(10,5,s,Red);
			show[9+(score1>=score2)][5].ch=' ';
		}
		if(p[1].dead){
			int left=(p[1].mv.nx-tm)/CPS+1;
			sprintf(tmps,"Respawn in %ds",left);
			Fill(8,60,tmps);
		}
		//����
		Weapon &wp=p[1].w1;
		Fill(2,58,WpnName[wp.tp]);
		sprintf(tmps,"%d/%d",wp.am,wp.full);
		Fill(3,61,tmps);
		if(!wp.am) show[3][61].setFG(Red);
		if(wp.R) Fill(4,58,"loading");
		Fill(6,58,WpnName[p[1].w2.tp]);
		conwp[wp.tp].FillMap();
	}

	inline void HandleKB(){	//Renew
		static CD nx=CD(CPS*0.2);
		RenewKeyboard();
		gt(tm);
		//if(KB_DOWN(VK_DELETE)) QuitGame();
		if(useF){
			if(KB_DOWN('X')){
				useF=0;
				return ;
			}
			for(int i=13; i<=32; i++)
				for(int j=43; j<=93; j++){
					show[i][j]=cN();
					if(i==13||i==32) show[i][j]=cN('-');
					if(j==43||j==93) show[i][j]=cN('|');
				}
			show[13][43]=show[13][93]=show[32][43]=show[32][93]=cN('+');
			NPCnode &t=npc[useF];
			Fill(14,46,t.name);
			if(curmap=="Factory"){
				Fill(17,50,"����������");
				if(!(plot&PLOT_SPLAY)) Fill(18,50,"�Ϲ�Դ�룺Splay      10000rp");
				if(!(plot&PLOT_DIJ))   Fill(19,50,"�Ϲ�Դ�룺Dijkstra   10000rp");
			}
			if(curmap=="Bar"){
				Fill(15,50,92,"�������ּ������˳��Ի���鿴��Ʒ���ܣ�����Ӧ�������õĵ��ǲ�����ʾЧ����");
				Fill(18,50,92,"0. ħצ    15rp");
				Fill(19,50,92,"1. ������  10rp");
				Fill(20,50,92,"2. ����    10rp");
				if(KB_DOWN('0')){
					if(rp<15) SendMsg("rp����","Waiter");
					else{
						SendMsg("�㹺����ħצ","Waiter");
						p[1].eff.push(Effect(EFF_SPD,0.3,120*CPS));
						p[1].eff.push(Effect(EFF_ATK,0.5,120*CPS));
					}
					useF=0;
					return ;
				}
				if(KB_DOWN('1')){
					if(rp<10) SendMsg("rp����","Waiter");
					else{
						SendMsg("�㹺���˿�����","Waiter");
						p[1].eff.push(Effect(EFF_CD,0.3,120*CPS));
					}
					useF=0;
					return ;
				}
				if(KB_DOWN('2')){
					if(rp<10) SendMsg("rp����","Waiter");
					else{
						SendMsg("�㹺��������","Waiter");
						p[1].eff.push(Effect(EFF_VAM,0.3,120*CPS));
					}
					useF=0;
					return ;
				}
			}
			if(curmap=="Street"){
				Fill(17,48,"���У������ϸ�ʱ���Ĵ�˵��~~");
				Fill(18,48,"�������ּ������£�����˳��");

				const static string st[10][2]={
					{ "0 1 ʱ��","01Era" },
					{ "��������","TwoDragons" },
					{ "��ʱ֮��","Archmage" },
					{ "�޾�ɭ��","InForest" },
					{ "ĩ·��;","LastGasp" }
				};
				for(int i=0; i<4; i++){
					Fill(20+i,50,(char)('0'+i)+(string)(". ")+st[i][0]);
					if(KB_DOWN(NUMBER(i))) ShowStory(st[i][1]);
				}
			}
			if(curmap=="Netbar"){
				Fill(15,50,"���RANK�鿴ͨ������");
				Fill(17,50,"���OJ�������棬20rpһ������");
				Fill(18,50,"Ӯ�˰����ѶȻ�ȡrp��");
			}
			Fill(31,46,"Press X to exit");
			return ;
		}
		if(p[1].mv.rea()){
			if(KB_DOWN(lastmv)){
				if(lastmv=='W') Move(-1,0);
				if(lastmv=='A') Move(0,-1);
				if(lastmv=='S') Move(1,0);
				if(lastmv=='D') Move(0,1);
			}else{
				if(KB_DOWN('W')) Move(-1,0);
				if(KB_DOWN('A')) Move(0,-1);
				if(KB_DOWN('S')) Move(1,0);
				if(KB_DOWN('D')) Move(0,1);
			}
		}
		if(KB_DOWN(VK_SPACE)) LockView();
		if(!nx.rea()) return ;
		if(KB_DOWN('Y')) useY^=1,nx.act();
		if(KB_DOWN('Q')){
			ActAbi(1,p[1].abiQ);
			nx.act();
		}else if(KB_DOWN('E')){
			ActAbi(1,p[1].abiE);
			nx.act();
		}else if(KB_DOWN('R')){
			p[1].Reload();
			nx.act();
		}else if(KB_DOWN(VK_SHIFT)){
			p[1].shift();
			if(curmap=="Home") SaveGame();
			nx.act();
		}else if(KB_DOWN('F')&&focusnpc){
			if(focusnpc) useF=focusnpc;
			nx.act();
		}
		return ;
	}
	void HandleFocus(){
		double x,y;
		GetCoord(x,y);
		int tot=quebut.size();
		while(tot--){
			Button b=quebut.front();
			quebut.pop();
			int t=b.key;
			if(b.Focus()){
				if(b.tp=="Arsenal wp"||b.tp=="Home wp") conwp[t].FillInfo();
				if(b.tp=="Arsenal ab"||b.tp=="Home ab") conab[t].FillInfo();
			}
			//quebut.push(b);
		}
		focusnpc=0;
		for(int i=1; i<=totnpc; i++)
			if(fabs(x-npc[i].x)<=0.5&&fabs(y-npc[i].y)<=0.8)
				focusnpc=i;
		focusobj=0;
		for(int i=1; i<=totobj; i++)
			if(fabs(x-obj[i].x)<=0.5&&fabs(y-obj[i].y)<=0.8)
				focusobj=i;
		return ;
	}
	void HandleLD(){
		static CD nx=CD(0.2*CPS);
		if(!nx.rea()) return ;
		nx.act();
		double x,y;
		GetCoord(x,y);
		if(sta==STA_FIGHT){
			Fire(1,x,y);
			return ;
		}
		int tot=quebut.size();
		//fout<<"tot "<<tot<<endl;
		while(tot--){
			Button b=quebut.front();
			quebut.pop();
			//fout<<b.tp<<endl;
			if(b.Focus()){
				int t=b.key;
				if(b.tp=="Home wp"){
					if(p[1].w1.tp==t||p[1].w2.tp==t) swap(p[1].w1,p[1].w2);
					else p[1].w1.Init(t);
					SaveGame();
				}
				if(b.tp=="Home ab"){
					if(p[1].abiQ.tp==t||p[1].abiE.tp==t) swap(p[1].abiQ,p[1].abiE);
					else p[1].abiQ.Init(t);
					SaveGame();
				}
				if(b.tp=="SPLAY"){
					SplayTree::Click(t);
				}
				if(b.tp=="Arsenal wp"){
					_cls();
					gotoxy(1,1);
					printf("������%s\n",WpnName[t]);
					printf("�������������� %drp\n",100);
					puts("�밴�£�");
					puts("0. �˳�");
					puts("1. ����rp����");
					do RenewKeyboard();
					while(!KB_DOWN('1')&&!KB_DOWN('0'));
					if(KB_DOWN('1')){
						if(rp<100) SendMsg("rp����");
						else rp-=100,hadwp|=1<<t,SendMsg((string)("�������")+WpnName[t]);
					}
					SaveGame();
				}
				if(b.tp=="Arsenal ab"){
					_cls();
					gotoxy(1,1);
					printf("���ܣ�%s\n",AbiName[t]);
					printf("�������������� %drp\n",100);
					puts("�밴�£�");
					puts("0. �˳�");
					puts("1. ����rp����");
					do RenewKeyboard();
					while(!KB_DOWN('1')&&!KB_DOWN('0'));
					if(KB_DOWN('1')){
						if(rp<100) SendMsg("rp����");
						else rp-=100,hadab|=1<<t,SendMsg((string)("�������")+AbiName[t]);
					}
					SaveGame();
				}
				if(b.tp=="computer"){
					if(rp<20) return SendMsg("rp����");
					rp-=20;
					SaveGame();
					lastmap=curmap;
					curmap.clear();
					for(int i=0; i<b.s.size(); i++)
						if(b.s[i]!=' ') curmap+=b.s[i];
					mode=0;
					_cls();
					while(1){
						gotoxy(1,1);
						puts("Choose a mode");
						for(int i=0; i<totmod; i++){
							if(mode==i) printf("> ");
							else printf("  ");
							puts(ModName[i]);
						}
						puts("");
						puts(" j k ѡ��Space ȷ��");
						RenewKeyboard();
						if(KB_DOWN('J')) mode=(mode+1)%totmod,Sleep(0.05*CPS);
						if(KB_DOWN('K')) mode=(mode+totmod-1)%totmod,Sleep(0.05*CPS);
						if(KB_DOWN(VK_SPACE)) break;
						Sleep(0.05*CPS);
					}
					Sleep(0.2*CPS);
					diff=0;
					_cls();
					while(1){
						gotoxy(1,1);
						puts("Choose difficulty ��ģʽԽ�ѻ�ȡrpԽ�ࣩ");
						for(int i=0; i<totdif; i++){
							if(diff==i) printf("> ");
							else printf("  ");
							puts(DifName[i]);
						}
						puts("");
						puts(" j k ѡ��Space ȷ��");
						RenewKeyboard();
						if(KB_DOWN('J')) diff=(diff+1)%totdif,Sleep(0.05*CPS);
						if(KB_DOWN('K')) diff=(diff+totdif-1)%totdif,Sleep(0.05*CPS);
						if(KB_DOWN(VK_SPACE)) break;
						Sleep(0.05*CPS);
					}
					Sleep(0.2*CPS);
					LoadMap();
					sta=STA_FIGHT;
					if(mode==MODE_SOLO){
						maxscore=5;
						totp=2;
					}
					if(mode==MODE_MATCH){
						maxscore=25;
						totp=10;
					}
					for(int i=1; i<=totp; i++)
						p[i].Init(i,i>totp/2);
				}
				return ;
			}
			//quebut.push(b);
		}
		focusnpc=0;
		for(int i=1; i<=totnpc; i++)
			if(fabs(x-npc[i].x)<=1.5&&fabs(y-npc[i].y)<=0.8)
				focusnpc=i;
		focusobj=0;
		for(int i=1; i<=totobj; i++)
			if(fabs(x-obj[i].x)<=0.5&&fabs(y-obj[i].y)<=0.8)
				focusobj=i;
		if(focusnpc) useF=focusnpc;
		return ;
	}

	void Renew(){	//����ʵ�����+AI
		sight=15;
		if(curmap=="Mines") sight=100;
		gt(tm);
		SetBasicInfo();	//��
		for(int i=1;i<=totp;i++){
			if(p[i].dead){
				if(p[i].mv.rea()) p[i].Respawn();
				else continue;
			}
			p[i].GetBuff();
			int tp=typ[p[i].x][p[i].y];
			Weapon &wp=p[i].w1;
			if(wp.R&&wp.cd.rea())
				wp.am=wp.full,wp.R=0;
			if(p[i].w2.R) p[i].w2.cd.nx=tm+p[i].w2.cd_r;
		}
		int tot=queflc.size();
		while(tot--){	//ɾ�����ڵ���Ч
			Flicker f=queflc.front();
			queflc.pop();
			if(f.tm>tm) queflc.push(f);
		}
		tot=quebul.size();
		while(tot--){	//�ӵ�
			Bullet b=quebul.front();
			quebul.pop();
			if(!b.las.rea()){
				quebul.push(b);
				continue;
			}
			long double sec=(double)(tm-b.las.nx)/CPS;
			b.las.nx=tm;
			//fout<<b.las.nx<<endl;
			int x=b.x+0.5,y=b.y+0.5;
			if(typ[x][y]){
				if(b.tp==WP_DART) b.dis=-1,b.con=0;
				else continue;
			}
			if(b.dis<eps){
				if(b.tp!=WP_DART||p[b.p].dead) continue;
				double x=p[b.p].x-b.x;
				double y=p[b.p].y-b.y;
				double d=getdis(x,y);
				d=max(d,eps);
				x*=b.spd/d;
				y*=b.spd/d;
				b.x+=x*sec;
				b.y+=y*sec;
			}else{
				b.x+=b.dx*sec;
				b.y+=b.dy*sec;
				b.dis-=b.spd*sec;
				if(b.dis<eps) b.con=0;	//dart
			}
			if(b.tp==WP_DART&&b.spin.rea()){
				char &c=b.ch.ch;
				if(c=='+') c='*';
				else c='+';
				b.spin.act();
			}
			int k=0;
			for(int i=1; i<=totp; i++)
				if(getdis(b.x,b.y,p[i].x,p[i].y)<=1){
					if(p[i].dead) continue;
					k|=1<<i-1;
					if(1<<i-1&b.con) continue;
					if(i==b.p){
						if(b.tp==WP_DART){
							if(b.dis>0) continue;
							if(p[i].w1.tp==WP_DART){
								p[i].w1.cd.act();
							}else{
								p[i].w2.am=1;
								p[i].w2.cd.act();
								p[i].w2.R=0;
							}
							//fout<<"back"<<endl;
						}
						k=-1;
						break;
					}
					Attack(b.p,i,b.dmg+(b.moon?(int)(0.1*p[i].hp+0.5):0));
					if(b.tp==WP_DART){
						if(p[b.p].abiQ.tp==ABI_RAID) p[b.p].abiQ.cd.nx=0;
						if(p[b.p].abiE.tp==ABI_RAID) p[b.p].abiE.cd.nx=0;
					}
					if(b.tp==WP_KATANA){
						p[b.p].eff.push(Effect(EFF_SPD,0.5,2*CPS));
						if(p[b.p].abiQ.tp==ABI_RAID) p[b.p].abiQ.cd.nx=0;
						if(p[b.p].abiE.tp==ABI_RAID) p[b.p].abiE.cd.nx=0;
					}
					if(b.tp!=WP_DART) k=-1;
				}
			if(~k) b.con=k,quebul.push(b);
		}
		RenewMouse();
		if(!p[1].dead){
			if(ChkLD()) HandleLD();
			else HandleFocus();
			HandleKB();
		}
		if(focusnpc){
			npc[focusnpc].FillInfo();
			show[5][53].ch='F';
		}
		if(focusobj){
			obj[focusobj].FillInfo();
			show[5][53].ch='F';
		}
		if(!useY) LockView();
		if(curmap=="Mines"&&!Mineswp::open(p[1].x,p[1].y)) ShowStory("MinesBomb"),QuitGame();
		if(curmap=="Forest"&&SplayTree::Check()){
			for(int i=14; i<=17; i++)
				typ[2][i]=0;
			for(int i=28; i<35; i++)
				conmp[2][i]=' ';
		}
		if(sta==STA_PEACE){
			p[1].abiQ.cd.nx=0;
			p[1].abiE.cd.nx=0;
		}
		if(sta==STA_FIGHT){
			for(int i=2; i<=totp; i++){
				if(p[i].dead||!p[i].ai.rea()) continue;
				p[i].GetSee();
				bool fe=FindEne(i);
				if(fe&&!p[i].combat) p[i].combat=1,p[i].ai.act();
				else if(!fe&&p[i].combat) p[i].combat=0;
				if(p[i].combat){
					p[i].ai.act();
					int ex=p[getene[1]].x,ey=p[getene[1]].y;
					desx[i]=ex,desy[i]=ey;
					double dis=getdis(p[i].x,p[i].y,ex,ey);
					if(p[i].w1.am&&dis<=p[i].w1.dis){
						//Fire(i,ex,ey);
						if(p[i].dif==DIFF_NORMAL) Fire(i,ex+rand()%5-2,ey+rand()%5-2);
						if(p[i].dif==DIFF_HARD)   Fire(i,ex+rand()%3-1,ey+rand()%3-1);
						if(p[i].dif==DIFF_INSANE) Fire(i,ex+p[getene[1]].dx/1.5,ey+p[getene[1]].dy/1.5);
					}else if(dis>p[i].w1.dis&&dis<=p[i].w2.dis&&p[i].w2.am) p[i].shift();
					else if(!p[i].w1.am&&!p[i].w2.am&&p[i].w2.dmg>p[i].w1.dmg) p[i].shift();
					else p[i].ai.nx=0;
					if(p[i].dif==DIFF_INSANE){
						if(dis<=15){
							if(p[i].abiQ.tp==ABI_FLASH&&p[i].abiQ.cd.rea()) ActAbi(i,p[i].abiQ,ex,ey);
							if(p[i].abiE.tp==ABI_FLASH&&p[i].abiE.cd.rea()) ActAbi(i,p[i].abiE,ex,ey);
							if(p[i].abiQ.tp==ABI_RAID&&p[i].abiQ.cd.rea()) ActAbi(i,p[i].abiQ,ex,ey);
							if(p[i].abiE.tp==ABI_RAID&&p[i].abiE.cd.rea()) ActAbi(i,p[i].abiE,ex,ey);
						}
					}
					if(!p[i].mv.rea()) continue;
					if(dis<=1.5){
						int t=rand()%4;
						Move(DIRE[t][0],DIRE[t][1],i);
					}else if(p[i].dif==DIFF_NORMAL){
						GotoDes(i);
					}else{
						RunAway(i);
					}
				}else if(p[i].mv.rea()){
					GotoDes(i);
				}
			}
			if(mode==MODE_SOLO){
				score1=5-p[2].life;
				score2=5-p[1].life;
			}
			if(mode==MODE_MATCH){
				score1=score2=0;
				for(int i=1; i<=totp; i++)
					if(p[i].hos) score2+=p[i].life;
					else score1+=p[i].life;
			}
			if(score1>=maxscore) Winner();
			if(score2>=maxscore) Loser();
			//Fill(8,32,p[2].x); Fill(9,32,p[2].y);
		}
		return ;
		sprintf(tmps,"%.2f %.2f",MouseX,MouseY); Fill(&show[7][42],tmps);
		double tmpx,tmpy;
		GetCoord(tmpx,tmpy);
		sprintf(tmps,"%.2f %.2f",tmpx,tmpy); Fill(&show[7][48],tmps);
		return ;
	}

	inline void RenewMap(){	//��ť��SetMap������
		//fout<<"RenewMap"<<endl;
		if(0) return p[1].SetMapPack();
		else SetMapNormal();
	}
	void Init(){
		fout.open("Debug.txt");
		HideCur();
		begin_t=clock();
		_cls();
		fin.open("screen.txt");
		for(int i=1; i<=40; i++)
			fin.getline(conscr[i]+1,137);//,fout<<conscr[i]+1<<endl;
		fin.close();
		fin.open("ads.txt");
		for(int i=0; i<5; i++)
			getline(fin,conads[i]);
		fin.close();
		dat.Init();
		hadwp=dat.hadwp;
		hadab=dat.hadab;
		plot=dat.plot;
		rp=dat.rp;
		//map: home
		p[1].Init(1);
		for(int i=1;i<=40;i++)
			for(int j=1;j<=135;j++)
				show[i][j]=cN(conscr[i][j]);
		for(int i=0; i<totwp; i++)
			conwp[i].Init(i),conwp[i].GetInfo();
		for(int i=0; i<totab; i++)
			conab[i].Init(i),conab[i].GetInfo();
		useY=0;
		quited=0;
		sta=STA_PEACE;	//
		if(!custom) ChangeMap("Home",10,10);
		return ;
	}
	void Start(bool cus=0){
		custom=cus;
		Init();
		Sleep(CPS*0.5);
		if(cus) StartCustomize();
		else if(plot==-1) Beginner();
		while(!quited){
			while(_kbhit()) _getch();
			RenewMap();
			Renew();
			Output::OutputMap();
			Sleep(CPS*0.01);
			//pau();
			/*

			   ����ͼ/���ɰ�ť
			   ����ʵ��/�����ͼ

			   ���

			 */
		}
		QuitGame();
		return ;
	}
	void SaveGame(){
		dat.plot=plot;
		dat.hadwp=hadwp;
		dat.hadab=hadab;
		dat.rp=rp;
		dat.rating=p[1].rating;
		dat.w1=p[1].w1.tp;
		dat.w2=p[1].w2.tp;
		dat.abiQ=p[1].abiQ.tp;
		dat.abiE=p[1].abiE.tp;
		dat.Save();
		SendMsg("Saved");
	}
	void StartCustomize(){
		int c=0;
		_cls();
		while(1){
			gotoxy(1,1);
			puts("Choose a map");
			for(int i=0; i<totmap; i++){
				if(c==i) printf("> ");
				else printf("  ");
				puts(MapName[i]);
			}
			puts("");
			puts(" j k ѡ��Space ȷ��");
			RenewKeyboard();
			if(KB_DOWN('J')) c=(c+1)%totmap,Sleep(0.05*CPS);
			if(KB_DOWN('K')) c=(c+totmap-1)%totmap,Sleep(0.05*CPS);
			if(KB_DOWN(VK_SPACE)) break;
			Sleep(0.05*CPS);
		}
		curmap=MapName[c];
		Sleep(0.2*CPS);
		c=0;
		_cls();
		while(1){
			gotoxy(1,1);
			puts("Choose a mode");
			for(int i=0; i<totmod; i++){
				if(c==i) printf("> ");
				else printf("  ");
				puts(ModName[i]);
			}
			puts("");
			puts(" j k ѡ��Space ȷ��");
			RenewKeyboard();
			if(KB_DOWN('J')) c=(c+1)%totmod,Sleep(0.05*CPS);
			if(KB_DOWN('K')) c=(c+totmod-1)%totmod,Sleep(0.05*CPS);
			if(KB_DOWN(VK_SPACE)) break;
			Sleep(0.05*CPS);
		}
		mode=c;
		Sleep(0.2*CPS);
		c=0;
		_cls();
		while(1){
			gotoxy(1,1);
			puts("Choose difficulty");
			for(int i=0; i<totdif; i++){
				if(c==i) printf("> ");
				else printf("  ");
				puts(DifName[i]);
			}
			puts("");
			puts(" j k ѡ��Space ȷ��");
			RenewKeyboard();
			if(KB_DOWN('J')) c=(c+1)%totdif,Sleep(0.05*CPS);
			if(KB_DOWN('K')) c=(c+totdif-1)%totdif,Sleep(0.05*CPS);
			if(KB_DOWN(VK_SPACE)) break;
			Sleep(0.05*CPS);
		}
		diff=c;
		Sleep(0.2*CPS);

		sta=STA_FIGHT;
		LoadMap();
		if(mode==MODE_SOLO){
			maxscore=5;
			totp=2;
		}
		if(mode==MODE_MATCH){
			maxscore=25;
			totp=10;
		}
		for(int i=1; i<=totp; i++)
			p[i].Init(i,i>totp/2);

		c=dat.w1;
		_cls();
		while(1){
			gotoxy(1,1);
			puts("Choose first weapon");
			for(int i=0; i<totwp; i++){
				if(c==i) printf("> ");
				else printf("  ");
				puts(WpnName[i]);
			}
			puts("");
			puts(" j k ѡ��Space ȷ��");
			RenewKeyboard();
			if(KB_DOWN('J')) c=(c+1)%totwp,Sleep(0.05*CPS);
			if(KB_DOWN('K')) c=(c+totwp-1)%totwp,Sleep(0.05*CPS);
			if(KB_DOWN(VK_SPACE)) break;
			Sleep(0.05*CPS);
		}
		p[1].w1.Init(c);
		Sleep(0.2*CPS);
		c=dat.w2;
		_cls();
		while(1){
			gotoxy(1,1);
			puts("Choose second weapon");
			for(int i=0; i<totwp; i++){
				if(c==i) printf("> ");
				else printf("  ");
				puts(WpnName[i]);
			}
			puts("");
			puts(" j k ѡ��Space ȷ��");
			if(c==p[1].w1.tp) puts("����ʹ����ͬ����");
			else puts("                             ");
			RenewKeyboard();
			if(KB_DOWN('J')) c=(c+1)%totwp,Sleep(0.05*CPS);
			if(KB_DOWN('K')) c=(c+totwp-1)%totwp,Sleep(0.05*CPS);
			if(c!=p[1].w1.tp&&KB_DOWN(VK_SPACE)) break;
			Sleep(0.05*CPS);
		}
		p[1].w2.Init(c);
		Sleep(0.2*CPS);
		c=dat.abiQ;
		_cls();
		while(1){
			gotoxy(1,1);
			puts("Choose Q ability");
			for(int i=0; i<totab; i++){
				if(c==i) printf("> ");
				else printf("  ");
				puts(AbiName[i]);
			}
			puts("");
			puts(" j k ѡ��Space ȷ��");
			RenewKeyboard();
			if(KB_DOWN('J')) c=(c+1)%totab,Sleep(0.05*CPS);
			if(KB_DOWN('K')) c=(c+totab-1)%totab,Sleep(0.05*CPS);
			if(KB_DOWN(VK_SPACE)) break;
			Sleep(0.05*CPS);
		}
		p[1].abiQ.Init(c);
		Sleep(0.2*CPS);
		c=dat.abiE;
		_cls();
		while(1){
			gotoxy(1,1);
			puts("Choose E ability");
			for(int i=0; i<totab; i++){
				if(c==i) printf("> ");
				else printf("  ");
				puts(AbiName[i]);
			}
			puts("");
			puts(" j k ѡ��Space ȷ��");
			if(c==p[1].abiQ.tp) puts("����ʹ����ͬ����");
			else puts("                             ");
			RenewKeyboard();
			if(KB_DOWN('J')) c=(c+1)%totab,Sleep(0.05*CPS);
			if(KB_DOWN('K')) c=(c+totab-1)%totab,Sleep(0.05*CPS);
			if(c!=p[1].abiQ.tp&&KB_DOWN(VK_SPACE)) break;
			Sleep(0.05*CPS);
		}
		p[1].abiE.Init(c);
		Sleep(0.2*CPS);
		return ;
	}
	void ShowStory(string st){
		static fstream fin;
		st="./story/"+st+".txt";
		fin.open(st.c_str());
		if(!fin) return SendMsg("Error Story "+st);
		SetColor(Normal,BGnormal);
		_cls();
		while(fin.getline(tmps,1000)){
			SlwPrt(tmps);
			do RenewKeyboard();
			while(!KB_DOWN(VK_RETURN));
		}
		fin.close();
		Sleep(0.5*CPS);
		RenewKeyboard();
		return ;
	}
	string GetRandName(){
		return "FFF";
	}
	inline void Beginner(){
		plot=0;
		hadwp=(1<<WP_KATANA)-1;
		hadab=(1<<ABI_FLASH)-1;
		p[1].w1.Init(0);
		p[1].w2.Init(1);
		p[1].abiQ.Init(0);
		p[1].abiE.Init(1);
		p[1].rating=1400;
		rp=1000;
		SaveGame();
		ShowStory("Begin");
		//cin.ignore(1000000,'\n');
	}
	void EncryptAll(){
		fin.open("./files.txt");
		string path;
		while(getline(fin,path),!path.empty()){
			path="./map-plot/"+path;
			EncryptF(path.c_str());
		}
		fin.close();
		return ;
	}
}
