namespace Color {
	const int Red = FOREGROUND_INTENSITY | FOREGROUND_RED;
	const int Blue = FOREGROUND_INTENSITY | FOREGROUND_BLUE;
	const int Green = FOREGROUND_INTENSITY | FOREGROUND_GREEN;
	const int Normal = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
	const int Black = 0;
	const int Grey = FOREGROUND_INTENSITY;
	const int Yellow = Green | Red;
	const int Purple = Red | Blue;
	const int Lblue = Green | Blue;
	const int White = FOREGROUND_INTENSITY | Normal;
	
	const int BGred = BACKGROUND_RED;
	const int BGLred = BACKGROUND_INTENSITY | BGred;
	const int BGblue = BACKGROUND_INTENSITY | BACKGROUND_BLUE;
	const int BGgreen = BACKGROUND_INTENSITY | BACKGROUND_GREEN;
	const int BGLblue = BGblue | BGgreen;
	const int BGyellow = BGLred |BGLblue;
	const int BGgrey = BACKGROUND_INTENSITY;
	const int BGgrwt = BACKGROUND_RED | BACKGROUND_BLUE | BACKGROUND_GREEN;
	const int BGwhite = BGgrwt | BACKGROUND_INTENSITY;
	const int BGnormal = 0;
	//	0000 0000
	//	 bg   fg
	//	irgb irgb
	inline void SetColor(int fg=0,int bg=0) {
		int color=fg|bg;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
	}
	void ColorTest(){
		puts("normal");
		SetColor(Red);
		puts("red");
		SetColor(Blue,BGLblue);
		puts("blue + BGLblue");
		SetColor(Green);
		puts("green");
		SetColor(White,BGred);
		puts("white + BGred");
		SetColor(Yellow);
		puts("yellow");
		SetColor(Purple);
		puts("purple");
		SetColor(Lblue,BGgrey);
		puts("Lblue + BGgrey");
		SetColor(FOREGROUND_INTENSITY,BGgrwt);
		puts("INTENSITY + BGgreywhite");
		SetColor(Normal);
		puts("normal");
		printf("fg %d bg %d\n",FOREGROUND_BLUE,BACKGROUND_RED);
	}
	inline int getFG(char c){
		if(c=='R') return Red;
		if(c=='r') return Red;
		if(c=='B') return Blue;
		if(c=='b') return Lblue;
		if(c=='G') return Green;
		if(c=='g') return Green;
		if(c=='Y') return Yellow;
		if(c=='W') return White;
		if(c=='N') return Normal;
		return -1;
	}
	inline int getBG(char c){
		if(c=='R') return BGred;
		if(c=='r') return BGLred;
		if(c=='B') return BGblue;
		if(c=='b') return BGLblue;
		if(c=='G') return BGgreen;
		if(c=='g') return BGgreen;
		if(c=='Y') return BGyellow;
		if(c=='W') return BGwhite;
		if(c=='w') return BGgrey;
		if(c=='N') return BGnormal;
		return -1;
	}
}
using namespace Color;
