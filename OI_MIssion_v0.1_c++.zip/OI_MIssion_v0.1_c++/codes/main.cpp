#include"opti.h"	//����47��
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<fstream>
#include<windows.h>
#include<conio.h>
using namespace std;
ifstream fin;
ofstream fout;
#include"color.h"
#include"other.h"
#include"cursor.h"
#include"game.h"

int main(){
	//Game::EncryptAll();
	//EncryptFile("./note1.txt");
	//ColorTest(); while(1);
	srand(time(NULL));
	InitCursor();
	Game::dat.Init();//Game::Start();
	cls();
	while(1){
		gotoxy(1,1);
		cout<<"��ң� "<<Game::dat.name<<endl;
		puts("��Ϸ��****\t\t\t\t\t�汾 v0.0.1");
		
		puts("���£�");
		puts("\t1 : ����ģʽ");
		puts("\t2 : �Զ���ģʽ");
		puts("\tEnter : �˳�");
		//Game::Start();
		if(_kbhit()){
			char ch=_getch();
			if(ch=='1') Game::Start();
			else if(ch=='2') Game::Start(1);
			else if(ch=='\r') break;
		}
		Sleep(0.1*CPS);
	}
	cls();
	fflush(stdin);
	pau();
	return 0;
}
