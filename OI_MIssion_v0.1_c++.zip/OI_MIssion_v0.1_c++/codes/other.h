typedef long long ll;
const double eps=1e-7;
#define INF 0x3f3f3f3f
#define pau() system("pause")
#define cls() system("cls")
#define CPS CLOCKS_PER_SEC
#define gt(tm) long tm=clock()
char tmps[1000000];

inline void SlwPrt(const char* s) {
	for(int i=0; s[i]; i++)
		putchar(s[i]),Sleep(0.002*CPS);
	puts("");
	Sleep(0.1*CPS);
	return ;
}

inline void Tutor() {
	system("start ../���ֽ̳�.txt");
}

inline int NUMBER(int x){
	return x+'0';
}

inline void Encrypt(char *s,int len){
	return ;
	//[-128,127]
	for(int i=0; i<len; i++)
		s[i]^=(i%256)^9;
}

inline void EncryptF(const char *path){
	FILE *fp=fopen(path,"rb");
	int len=fread(tmps,1,sizeof(tmps),fp);
	fclose(fp);
	Encrypt(tmps,len);
	fp=fopen(path,"wb");
	fwrite(tmps,len,1,fp);
	fclose(fp);
}
